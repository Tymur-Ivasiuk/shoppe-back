$(document).ready(function() {
    $('.header_burger').click(function() {
        console.log('ckad')
        $('.header-menu, .header_burger').toggleClass('active-header');
    })
})
